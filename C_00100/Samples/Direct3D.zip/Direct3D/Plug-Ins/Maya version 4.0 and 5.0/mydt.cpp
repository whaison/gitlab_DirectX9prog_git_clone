
#include "MyDt.h"
#include <assert.h>



extern bool	g_bRelativeTexFile;
extern bool	g_bExportAnimation;
extern bool	g_bKeyframeAnimation;
extern bool	g_bAnimateEverything;
extern int		g_iFrameStep;
extern int		g_iFlipU;
extern int		g_iFlipV;
extern bool	g_bExportPatches;

extern CArrayTable g_Arrays;







SMesh::SMesh() 
{
	m_kType = SMesh::UNKNOWN;

	m_nGroups = 0;
	m_aGroups = NULL;

	m_nPoints = 0;
	m_aPoints = NULL;

	m_nVertexColors = 0;
	m_aVertexColors = NULL;

	m_nNormals = 0;
	m_aNormals = NULL;

	m_nUVs = 0;
	m_aUVs = NULL;

	m_nReps = 0;
	m_aReps = NULL;

	m_nFaces = 0;
	m_aFaces = NULL;

    m_nFaceIndices = 0;

	m_nBones = 0;
	m_aBones = NULL;

	m_nMaxBonesPerFace = 0;
	m_nMaxBonesPerPoint = 0;
}



SMesh::~SMesh() 
{
	delete[] m_aReps;

	delete[] m_aPoints;
	delete[] m_aNormals;
	delete[] m_aUVs;
	delete[] m_aVertexColors;

	for (UINT iFace = 0; iFace < m_nFaces; iFace++)
	{
		delete[] m_aFaces[iFace].m_aIndices;
	}

	delete[] m_aFaces;

	delete[] m_aGroups;

	for (UINT iBone = 0; iBone < m_nBones; iBone++) 
	{
		delete[] m_aBones[iBone].m_afWeights;
		delete[] m_aBones[iBone].m_aiPoints;
	}

	delete[] m_aBones;
}


SFace::SFace()
{
	m_nIndices	= 0;
	m_aIndices	= NULL;

	m_iGroup	= -1;
}

SFace::~SFace() 
{
}


SBone::SBone()
{
	m_szName = NULL;

	m_nReps = 0;

	m_nWeights = 0;
	m_afWeights	= NULL;
	m_aiPoints  = NULL;

	// set matrices to IDENITY
	for (UINT i = 0; i < 4; i++)
	{
		for (UINT j = 0; j < 4; j++)
		{
			m_aafOffset[i][j] = 0.0f;
		}

		m_aafOffset[i][i] = 1.0f;
	}
}

SBone::~SBone()
{
}

SAnim::SAnim()
{
	m_szName = NULL;

	m_nKeys = 0;
	m_aKeys = NULL;
}

SAnim::~SAnim()
{
	delete[] m_aKeys;
}




/*




int	MyDtShapeGetControlPoints
	(
		MObject&	objInput, 
		MObject&	objOutput, 
		UINT*		pcVertices, 
		DtVec3f**	prgVertices
	) 
{
	*pcVertices		= 0;
	*prgVertices	= NULL;

	
	assert(objInput.hasFn(MFn::kNurbsSurface) && objOutput.hasFn(MFn::kNurbsSurface));


	MFnNurbsSurface	fnOutput(objOutput);
	MFnNurbsSurface	fnInput(objInput);



	MPointArray rgCVs;

	fnInput.getCVs(rgCVs);

	*pcVertices		= rgCVs.length();
	*prgVertices	= new DtVec3f[*pcVertices];

	if (!*prgVertices) 
	{
		*pcVertices	= 0;

		return 0;
	}

	// WARNING:  Is this homogeneous coordinates? Should I divide w?
	for (UINT iVertex = 0; iVertex < *pcVertices; iVertex++) 
	{
		(*prgVertices)[iVertex].vec[0]	= (float)rgCVs[iVertex][0];
		(*prgVertices)[iVertex].vec[1]	= (float)rgCVs[iVertex][1];
		(*prgVertices)[iVertex].vec[2]	= (float)rgCVs[iVertex][2];
	}


	// check for tweaks
	MPlug	plgTweakLoc	= fnOutput.findPlug("tweakLocation");

	MObject	objTweakLocVal;

	plgTweakLoc.getValue(objTweakLocVal);

	if (!objTweakLocVal.isNull())	// tweak found
	{	
		MPlugArray	rgplgTweakLocConnections;

		plgTweakLoc.connectedTo(rgplgTweakLocConnections, true, false);		// get source plugs

		assert(rgplgTweakLocConnections.length() == 1);

		MObject	objTweak = rgplgTweakLocConnections[0].node();

		assert(objTweak.hasFn(MFn::kTweak));

		MFnGeometryFilter	fnTweak(objTweak);

		bool	bRelativeTweak;

		fnTweak.findPlug("relativeTweak").getValue(bRelativeTweak);

		if (!bRelativeTweak) 
			cout << "\t\tWARNING: Encountered an absolute tweak; treating as relative!" << endl;

		MPlug plgOffsets = fnTweak.findPlug("plist")[0].child(0);


		//	WARNING: Seems like Maya doesn't initialize it's numElements properly!!
//		assert((int)plgOffsets.numElements() == cVertices);
		if ((int)plgOffsets.numElements() != *pcVertices)
			cout << "\t\tWARNING: tweak count doesn't match vertex count!" << endl;

		float	fEnvelope	= fnTweak.envelope();

		for (UINT iVertex = 0; iVertex < *pcVertices; iVertex++) 
		{
			DtVec3f	vecOffset;

			plgOffsets.elementByLogicalIndex(iVertex).child(0).getValue(vecOffset.vec[0]);
			plgOffsets.elementByLogicalIndex(iVertex).child(1).getValue(vecOffset.vec[1]);
			plgOffsets.elementByLogicalIndex(iVertex).child(2).getValue(vecOffset.vec[2]);

			(*prgVertices)[iVertex].vec[0]	+= fEnvelope * vecOffset.vec[0];
			(*prgVertices)[iVertex].vec[1]	+= fEnvelope * vecOffset.vec[1];
			(*prgVertices)[iVertex].vec[2]	+= fEnvelope * vecOffset.vec[2];
		}
	}
			
			

	return 1;
}


*/