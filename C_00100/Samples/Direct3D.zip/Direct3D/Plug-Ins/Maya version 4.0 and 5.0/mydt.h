#ifndef MyDt_h
#define MyDt_h


#include <MDt.h>	// Dt API
#include <maya/MTransformationMatrix.h>

struct SRep 
{
	UINT m_iUV;		// index into lump of texture coordinates 
	UINT m_iNorm;	// index into lump of normals
	UINT m_iNext;	// next repetition
	UINT m_iFirst;	// can also be thought of as "index into lump of vertices";

	// IMPORTANT: the following members are only valid in the instances corresponding to the first rep's.
	UINT m_nReps;					
};


struct SFace 
{
	SFace();
   ~SFace();

	UINT m_nIndices;		// number of vertices in this face
	UINT* m_aIndices;
	long m_iGroup;			// material group
};



struct SGroup 
{
	char* m_szName;			// material name
	char* m_szTextureFile;	// texture file name
	float m_fDiffuseRed;	// diffuse components	
	float m_fDiffuseGreen;	
	float m_fDiffuseBlue;		
	float m_fSpecularRed;	// specular components	
	float m_fSpecularGreen;	
	float m_fSpecularBlue;		
	float m_fEmissiveRed;	// emissive components	
	float m_fEmissiveGreen;	
	float m_fEmissiveBlue;		
	float m_fShininess;		// specular power
	float m_fTransparency;	// transparency
};


struct SBone 
{
	SBone();
   ~SBone();

	char* m_szName;				// bone name
	UINT m_nReps;				// number of reps influenced
	UINT m_nWeights;			// number of points influenced
	float* m_afWeights;
	UINT* m_aiPoints;
	float m_aafOffset[4][4];	// inverse of bone's world coordinate transform at the time of binding
};


struct SMesh 
{
	SMesh();
   ~SMesh();

	enum ShapeType
	{
		UNKNOWN,
		POLY_MESH,
		PATCH_MESH,
		BONE
	};

	ShapeType m_kType;
	// control point info
	UINT m_nReps;
	SRep* m_aReps;
	UINT m_nPoints;
	DtVec3f* m_aPoints;		// lump of vertices
	UINT m_nNormals;
	DtVec3f* m_aNormals;	// lump of normals
	UINT m_nUVs;
	DtVec2f* m_aUVs;		// lump of texture coords
	UINT m_nVertexColors;
	DtRGBA* m_aVertexColors;// lump of vertex colors
	// face info
	UINT m_nFaces;
	SFace* m_aFaces;
	UINT m_nFaceIndices;	// total number of face indices (over all faces).
	// material info
	UINT m_nGroups;
	SGroup* m_aGroups;		// material groups
	// skinning info
	UINT m_nBones;
	SBone* m_aBones;
	UINT m_nMaxBonesPerPoint;
	UINT m_nMaxBonesPerFace;
};


struct SKey 
{
	UINT m_iFrame;
	float m_afPosition[3];		// translation
	float m_afScale[3];			// scale
	float m_afQuaternion[4];	// quaternion rotation
	float m_afRotation[3];		// euler angles	- NOT USED
};


struct SAnim 
{
	SAnim();
	~SAnim();

	char* m_szName;
	UINT m_nKeys;
	SKey* m_aKeys;
};









typedef enum { FLOAT_ARRAY, STRING, CHAR_ARRAY } ArrayType_t;

class CArrayTable
{
private:
	char**	m_aacCharTable;
	UINT	m_uCharTableSize;
	UINT	m_uCharTableMax;

	float**	m_aafFloatTable;
	UINT	m_uFloatTableSize;
	UINT	m_uFloatTableMax;

public:
	CArrayTable() {};
	~CArrayTable() {};

	HRESULT Initialize();
	HRESULT Add(ArrayType_t, void*);
	HRESULT CleanUp();
};


inline HRESULT CArrayTable::Initialize()
{
	m_uCharTableSize = 0;
	m_uCharTableMax  = 64;

	m_uFloatTableSize = 0;
	m_uFloatTableMax  = 64;

	m_aacCharTable = NULL;
	m_aacCharTable = new char*[m_uCharTableMax];
	if (m_aacCharTable == NULL)
		return E_OUTOFMEMORY;

	m_aafFloatTable = NULL;
	m_aafFloatTable = new float*[m_uFloatTableMax];
	if (m_aafFloatTable == NULL)
		return E_OUTOFMEMORY;

	return S_OK;
}

inline HRESULT CArrayTable::CleanUp()
{
	UINT i;

	if (m_aacCharTable != NULL)
	{
		for (i = 0; i < m_uCharTableSize; i++)
			delete[] m_aacCharTable[i];

		delete[] m_aacCharTable;
	}

	if (m_aafFloatTable != NULL)
	{
		for (i = 0; i < m_uFloatTableSize; i++)
			delete[] m_aafFloatTable[i];

		delete[] m_aafFloatTable;
	}

	return S_OK;
}



inline HRESULT CArrayTable::Add(ArrayType_t ArrayType, void* avArray) 
{

	switch(ArrayType)
	{
	case CHAR_ARRAY:
	case STRING:
		if (m_uCharTableSize >= m_uCharTableMax) 
		{	// double the array size

			char** aacCharTable = m_aacCharTable;

			m_uCharTableMax *= 2;

			m_aacCharTable = NULL;
			m_aacCharTable = new char*[m_uCharTableMax];
			if (m_aacCharTable == NULL) 
			{
				m_aacCharTable = aacCharTable;
				return E_OUTOFMEMORY;
			}

			memcpy(m_aacCharTable, aacCharTable, m_uCharTableSize * sizeof(char*));

			delete[] aacCharTable;
		}

		m_aacCharTable[m_uCharTableSize++] = (char*)avArray;
		break;
	case FLOAT_ARRAY:
		if (m_uFloatTableSize >= m_uFloatTableMax) 
		{	// double the array size

			float** aafFloatTable = m_aafFloatTable;

			m_uFloatTableMax *= 2;

			m_aafFloatTable = NULL;
			m_aafFloatTable = new float*[m_uFloatTableMax];
			if (m_aafFloatTable == NULL) 
			{
				m_aafFloatTable = aafFloatTable;
				return E_OUTOFMEMORY;
			}

			memcpy(m_aafFloatTable, aafFloatTable, m_uFloatTableSize * sizeof(float*));

			delete[] aafFloatTable;
		}

		m_aafFloatTable[m_uFloatTableSize++] = (float*)avArray;
		break;
	default:
		return E_FAIL;	// array type not found
	}

	return S_OK;
}
























#endif