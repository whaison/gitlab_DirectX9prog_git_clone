//#include <windows.h>
#include "d3dx9.h"
#include <d3dtypes.h>
#include <stdio.h>
#include <malloc.h>
#include "common.h"
#include "gxcrackfvf.h"
#include "gxu.h"
#include "crackdecl.h"


