//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PlayMulti.rc
//
#define IDD_MAIN                        101
#define IDR_MAINFRAME                   102
#define IDC_FILENAME1                   1000
#define IDC_FILENAME2                   1001
#define IDC_FILENAME3                   1002
#define IDC_PLAY1                       1010
#define IDC_PLAY2                       1011
#define IDC_PLAY3                       1012
#define IDC_BUTTON1                     1019
#define IDC_STOPALL                     1019
#define IDC_SOUNDFILE1                  1020
#define IDC_SOUNDFILE2                  1021
#define IDC_SOUNDFILE3                  1022
#define IDC_LOOPED1                     1030
#define IDC_LOOPED2                     1031
#define IDC_LOOPED3                     1032
#define IDC_CONTROL1                    1040
#define IDC_CONTROL2                    1041
#define IDC_CONTROL3                    1042
#define IDC_RADIO_DEFAULT1              1050
#define IDC_RADIO_IMMEDIATE1            1051
#define IDC_RADIO_GRID1                 1052
#define IDC_RADIO_BEAT1                 1053
#define IDC_RADIO_MEASURE1              1054
#define IDC_RADIO_DEFAULT2              1060
#define IDC_RADIO_IMMEDIATE2            1061
#define IDC_RADIO_GRID2                 1062
#define IDC_RADIO_BEAT2                 1063
#define IDC_RADIO_MEASURE2              1064
#define IDC_RADIO_DEFAULT3              1065
#define IDC_RADIO_IMMEDIATE3            1066
#define IDC_RADIO_GRID3                 1070
#define IDC_RADIO_BEAT3                 1071
#define IDC_RADIO_MEASURE3              1072

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
