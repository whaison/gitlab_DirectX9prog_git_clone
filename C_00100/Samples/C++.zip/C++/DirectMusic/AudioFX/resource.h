//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by audiofx.rc
//
#define IDD_MAIN                        101
#define IDI_ICON                        103
#define IDC_PARAM_NAME1                 1000
#define IDC_PARAM_VALUE1                1001
#define IDC_SLIDER1                     1002
#define IDC_PARAM_MIN1                  1003
#define IDC_PARAM_MAX1                  1004
#define IDC_PARAM_NAME2                 1005
#define IDC_PARAM_VALUE2                1006
#define IDC_SLIDER2                     1007
#define IDC_PARAM_MIN2                  1008
#define IDC_PARAM_MAX2                  1009
#define IDC_PARAM_NAME3                 1010
#define IDC_PARAM_VALUE3                1011
#define IDC_SLIDER3                     1012
#define IDC_PARAM_MIN3                  1013
#define IDC_PARAM_MAX3                  1014
#define IDC_PARAM_NAME4                 1015
#define IDC_PARAM_VALUE4                1016
#define IDC_SLIDER4                     1017
#define IDC_PARAM_MIN4                  1018
#define IDC_PARAM_MAX4                  1019
#define IDC_PARAM_NAME5                 1020
#define IDC_PARAM_VALUE5                1021
#define IDC_SLIDER5                     1022
#define IDC_PARAM_MIN5                  1023
#define IDC_PARAM_MAX5                  1024
#define IDC_PARAM_NAME6                 1025
#define IDC_PARAM_VALUE6                1026
#define IDC_SLIDER6                     1027
#define IDC_PARAM_MIN6                  1028
#define IDC_PARAM_MAX6                  1029
#define IDC_RADIO_TRIANGLE              1101
#define IDC_RADIO_SQUARE                1102
#define IDC_RADIO_SINE                  1103
#define IDC_RADIO_CHORUS                1201
#define IDC_RADIO_COMPRESSOR            1202
#define IDC_RADIO_DISTORTION            1203
#define IDC_RADIO_ECHO                  1204
#define IDC_RADIO_FLANGER               1205
#define IDC_RADIO_GARGLE                1206
#define IDC_RADIO_PARAMEQ               1207
#define IDC_RADIO_REVERB                1208
#define IDC_CHECK_CHORUS                1211
#define IDC_CHECK_COMPRESSOR            1212
#define IDC_CHECK_DISTORTION            1213
#define IDC_CHECK_ECHO                  1214
#define IDC_CHECK_FLANGER               1215
#define IDC_CHECK_GARGLE                1216
#define IDC_CHECK_PARAMEQ               1217
#define IDC_CHECK_REVERB                1218
#define IDC_BUTTON_OPEN                 1301
#define IDC_TEXT_STATUS                 1302
#define IDC_TEXT_FILENAME               1303
#define IDC_CHECK_LOOP                  1304
#define IDC_BUTTON_PLAY                 1305
#define IDC_BUTTON_STOP                 1306
#define IDC_FRAME                       1307
#define IDC_FRAME_WAVEFORM              1309
#define IDC_RADIO_NEG_180               1310
#define IDC_RADIO_NEG_90                1311
#define IDC_RADIO_ZERO                  1312
#define IDC_RADIO_90                    1313
#define IDC_RADIO_180                   1314
#define IDC_FRAME_PHASE                 1315

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1316
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
