//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AudioScripts.rc
//
#define IDD_MAIN                        101
#define IDR_MAINFRAME                   102
#define IDC_COMBO_SCRIPT                1000
#define IDC_EDIT_ABOUT                  1001
#define IDC_BUTTON_ROUTINE1             2001
#define IDC_BUTTON_ROUTINE2             2002
#define IDC_BUTTON_ROUTINE3             2003
#define IDC_EDIT_VARIABLE1              3001
#define IDC_EDIT_VARIABLE2              3002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
