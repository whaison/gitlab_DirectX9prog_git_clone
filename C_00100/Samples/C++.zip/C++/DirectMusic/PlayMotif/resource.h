//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PlayMotif.rc
//
#define IDD_MAIN                        101
#define IDR_MAINFRAME                   102
#define IDR_ACCELERATOR1                131
#define IDC_PLAY                        1002
#define IDC_STOP                        1003
#define IDC_FILENAME                    1004
#define IDC_STATUS                      1005
#define IDC_MOTIF_LIST                  1008
#define IDC_LOOP_CHECK                  1009
#define IDC_SOUNDFILE                   1011
#define IDC_PLAY_MOTIF                  1015
#define IDC_RADIO_DEFAULT               1016
#define IDC_RADIO_IMMEDIATE             1017
#define IDC_RADIO_GRID                  1018
#define IDC_RADIO_BEAT                  1019
#define IDC_RADIO_MEASURE               1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
