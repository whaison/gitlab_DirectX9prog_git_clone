//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LobbyClientCE.rc
//
#define IDD_LOBBY_CLIENT                101
#define IDC_SP_COMBO                    1005
#define IDC_SESSION_NAME                1006
#define IDC_PLAYER_NAME                 1007
#define IDC_ADAPTER_COMBO               1008
#define IDC_SIP                         1009
#define IDC_ADDRESS                     1011
#define IDC_LOCAL_PORT                  1012
#define IDC_STATUS                      1013
#define IDC_LAUNCH                      1014
#define IDC_ACTIVE_CONNECTIONS          1017
#define IDC_APP_LIST                    1018
#define IDC_DISCONNECT                  1019
#define IDC_SEND_MSG                    1020
#define IDC_HOST_SESSION                1021
#define IDC_NO_SETTINGS                 1022
#define IDC_OVERRIDE_LOCAL_PORT         1023
#define IDC_REMOTE_PORT                 1024
#define IDC_ADDRESS_TEXT                1025
#define IDC_REMOTE_PORT_TEXT            1026
#define IDC_LAUNCH_NEW                  1029
#define IDC_LAUNCH_NOT_FOUND            1030
#define IDC_DONT_LAUNCH                 1031
#define IDI_MAIN                        11014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
