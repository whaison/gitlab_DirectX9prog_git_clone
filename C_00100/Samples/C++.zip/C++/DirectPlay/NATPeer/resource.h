//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NatPeerCE.rc
//
#define IDD_MAIN_GAME                   101
#define IDD_NATPEER                     102
#define IDD_CONNECT                     102
#define IDD_SEARCH                      105
#define IDI_MAIN                        106
#define IDC_WAVE                        1001
#define IDC_NUM_PLAYERS                 1002
#define IDC_PLAYER_NAME                 1003
#define IDC_SP_COMBO                    1005
#define IDC_SESSION_NAME                1006
#define IDC_LOCAL_IP                    1007
#define IDC_ADAPTER_COMBO               1008
#define IDC_ADDRESS_LINE1               1011
#define IDC_LOG_EDIT                    1016
#define IDC_HOST_SESSION                1021
#define IDC_ADDRESS_LINE2               1024
#define IDC_ADDRESS_LINE1_TEXT          1025
#define IDC_ADDRESS_LINE2_TEXT          1026
#define IDC_SIP                         1027
#define IDC_STATUS_BAR_TEXT             1028
#define IDC_ENABLE_RESOLUTION           1033
#define IDC_SERVER_ADDRESS              1034
#define IDC_PASSWORD                    1035
#define IDC_CONNECT                     1036
#define IDC_EDIT1                       1037
#define IDC_SEARCH_ADDRESS              1037
#define IDC_SERVER_PORT                 1037
#define IDC_BUTTON1                     1038
#define IDC_SEARCH                      1038
#define IDC_APPHELP                     1038
#define IDC_LIST1                       1039
#define IDC_SESSIONS                    1039
#define IDC_REMOTE_PORT                 1040
#define IDC_LOCAL_PORT                  1041
#define IDC_EDIT2                       1042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
