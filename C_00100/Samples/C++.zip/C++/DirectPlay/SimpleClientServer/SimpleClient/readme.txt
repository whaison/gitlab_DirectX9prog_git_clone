//-----------------------------------------------------------------------------
// 
// Sample Name: SimpleClientServer Sample
// 
// Copyright (c) 1999-2001 Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  The SimpleClientServer sample is a simple client/server application. 

Path
====
  Source: Mssdk\Samples\Multimedia\DirectPlay\SimpleClientServer 

  Executable: Mssdk\Samples\Multimedia\DirectPlay\Bin


