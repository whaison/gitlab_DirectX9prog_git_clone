//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NatResolver.rc
//
#define IDD_NATRESOLVER                 101
#define IDI_MAIN                        101
#define IDD_STARTSERVER                 103
#define IDC_APPHELP                     1000
#define IDC_USERSTRING                  1001
#define IDE_USERSTRING                  1002
#define IDC_QUERIES                     1003
#define IDC_RESPONSES                   1004
#define IDC_ADDRESSES                   1007
#define IDC_SIP                         1008
#define IDC_PORT                        1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
