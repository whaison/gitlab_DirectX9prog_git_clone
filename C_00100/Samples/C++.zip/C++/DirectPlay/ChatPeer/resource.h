//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by chatpeerCE.rc
//
#define IDD_MAIN_GAME                   101
#define IDC_WAVE                        1001
#define IDC_NUM_PLAYERS                 1002
#define IDC_PLAYER_NAME                 1003
#define IDC_CHAT_EDIT                   1010
#define IDC_CHAT_LISTBOX                1012
#define IDC_SEND                        1034
#define IDC_SIP                         1035
#define IDC_INFO                        1036
#define IDC_STATUS_BAR_TEXT             1039
#define IDD_MULTIPLAYER_CONNECT         10001
#define IDD_MULTIPLAYER_GAMES           10002
#define IDD_MULTIPLAYER_CREATE          10003
#define IDD_LOBBY_WAIT_STATUS           10004
#define IDD_MULTIPLAYER_ADDRESS         10005
#define IDC_RETURN                      11001
#define IDC_PLAYER_NAME_EDIT            11002
#define IDC_GAMES_LIST                  11003
#define IDC_JOIN                        11004
#define IDC_CREATE                      11005
#define IDC_CONNECTION_LIST             11006
#define IDC_BACK                        11007
#define IDC_EDIT_SESSION_NAME           11009
#define IDC_SEARCH_CHECK                11010
#define IDC_LOBBYCONNECTCANCEL          11011
#define IDC_WAIT_TEXT                   11012
#define IDC_MIGRATE_HOST                11013 
#define IDI_MAIN                        11014
#define IDC_IP_ADDRESS                  11015
#define IDC_SIGNING_FAST                11016
#define IDC_SIGNING_FULL                11017
#define IDC_LOCAL_PORT                  11018
#define IDC_LOCAL_PORT_TEXT             11019
#define IDC_USE_DPNSVR                  11020
#define IDC_REMOTE_PORT                 11021
#define IDC_REMOTE_HOSTNAME             11022
#define IDD_SI_MAIN                     15000
#define IDD_SI_PLAYERS                  15001
#define IDD_SI_MESSAGES                 15002
#define IDC_SI_PLAYERS                  16000
#define IDC_SI_GROUPS                   16001
#define IDC_SI_DESCRIPTION              16002
#define IDC_SI_NAME_BORDER              16003
#define IDC_SI_NAME                     16004
#define IDC_SI_MEMBERSHIP               16005
#define IDC_SI_MEMBERSHIP_TEXT          16006
#define IDC_SI_NAME_ICON                16007
#define IDC_SI_DPLAYMSG                 16008
#define IDC_SI_APPMSG                   16009
#define IDC_SI_TAB                      16010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
