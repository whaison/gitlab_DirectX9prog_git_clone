//----------------------------------------------------------------------------
// File: 
//
// Desc: 
//
// Copyright (c) Microsoft Corp. All rights reserved.
//-----------------------------------------------------------------------------
#ifndef _IDPCLIENT_H
#define _IDPCLIENT_H


#endif