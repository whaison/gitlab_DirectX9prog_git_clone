//----------------------------------------------------------------------------
// File: 
//
// Desc: 
//
// Copyright (c) Microsoft Corp. All rights reserved.
//-----------------------------------------------------------------------------
#ifndef _IDPSERVER_H
#define _IDPSERVER_H

#endif