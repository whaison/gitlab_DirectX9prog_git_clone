//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winmain.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDD_SELECTDEVICE                144
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_DEVICECLIP_CHECK            1012
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDD_VSHADER                     1019
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_TOGGLESTART                 40004
#define IDM_SINGLESTEP                  40005
#define IDM_EXIT                        40006
#define IDM_HELP                        40007
#define IDM_OPENFILE                    40011
#define IDM_SHOWOPTIMIZEDMESH           40012
#define ID_OPTIONS_DISPLAY1             40014
#define ID_OPTIONS_DISPLAY4             40015
#define ID_OPTIONS_DISPLAY9             40016
#define ID_OPTIONS_DISPLAY16            40017
#define ID_OPTIONS_DISPLAY25            40018
#define ID_OPTIONS_DISPLAY36            40019
#define IDM_SHOWSTRIPS                  40020
#define IDM_SHOWSINGLESTRIP             40021
#define IDM_CACHESIZE_12                40022
#define IDM_CACHESIZE_13                40023
#define IDM_CACHESIZE_14                40024
#define IDM_CACHESIZE_15                40025
#define IDM_CACHESIZE_16                40026
#define IDM_CACHESIZE_17                40027
#define IDM_CACHESIZE_18                40028
#define IDM_MAGICNUMBER_5               40029
#define IDM_MAGICNUMBER_6               40030
#define IDM_MAGICNUMBER_7               40031
#define IDM_MAGICNUMBER_8               40032
#define IDM_MAGICNUMBER_9               40033
#define IDM_MAGICNUMBER_10              40034
#define IDM_SHOWXBOX                    40035
#define IDM_LOADTAMER                   40036
#define IDM_DYNAMICVB                   40037
#define IDM_SHOWNONOPTIMIZEDMESH        40038
#define IDM_SHOWONESTRIP                40039
#define IDM_SHOWMANYSTRIPS              40040
#define IDM_FORCE32BYTEVERTEX           40041
#define IDM_SHOWSTRIPREORDERED          40042
#define IDM_SHOWVCACHEOPTIMIZED         40043
#define IDM_SHOWTRILIST                 40044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40045
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
