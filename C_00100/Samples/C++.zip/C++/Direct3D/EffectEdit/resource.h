//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EffectEdit.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_RENDER_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_EFFECTEDITTYPE              129
#define ID_INDICATOR_ROW                129
#define IDD_OPTIONS_FORM                130
#define ID_INDICATOR_COL                130
#define IDD_ERRORS_FORM                 132
#define IDD_EFFECTTEXT_FORM             134
#define IDD_LIGHTS                      136
#define IDD_TABS                        137
#define IDR_FX1                         138
#define IDR_UIELEMENT_FX                138
#define IDR_ARROW_X                     139
#define ID_EDIT_USEEXTERNALEDITOR       140
#define ID_EDIT_USESHADEROPTIMIZATION   141
#define ID_FILE_DEFAULTTODXSDKMEDIAFOLDER 142
#define ID_EDIT_FIND143                 143
#define IDD_SELECTDEVICE                144
#define IDR_HELP_TXT                    145
#define IDC_RENDERTEXT                  1000
#define IDC_DEVICE_COMBO                1000
#define IDC_GROUPBOX                    1001
#define IDC_RENDERWINDOW                1002
#define IDC_ADAPTER_COMBO               1002
#define IDC_RADIO1                      1003
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RADIO2                      1004
#define IDC_RESOLUTION_COMBO            1004
#define IDC_RADIO3                      1005
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_RADIO4                      1006
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_WIREFRAME                   1006
#define IDC_RADIO5                      1007
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_NOTEXTURES                  1007
#define IDC_RADIO6                      1008
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_WITHTEXTURES                1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_LIST                        1010
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_EDIT                        1011
#define IDC_DEVICECLIP_CHECK            1012
#define IDC_TECHNIQUELIST               1015
#define IDC_WINDOW                      1016
#define IDC_CHECK1                      1016
#define IDC_PASSLIST                    1016
#define IDC_EDIT1                       1017
#define IDC_FULLSCREEN                  1018
#define IDC_EDIT2                       1018
#define IDC_EDIT3                       1019
#define IDC_EDIT4                       1020
#define IDC_COMBO1                      1021
#define IDC_BUTTON1                     1022
#define IDC_BUTTON2                     1023
#define IDC_EDIT5                       1024
#define IDC_SHOWSTATS                   1024
#define IDC_EDIT6                       1025
#define IDC_EDIT7                       1026
#define IDC_EDIT8                       1027
#define IDC_SELECTEDPASS                1027
#define IDC_EDIT9                       1028
#define IDC_UPTOSELECTEDPASS            1028
#define IDC_EDIT10                      1029
#define IDC_ALLPASSES                   1029
#define IDC_EDIT11                      1030
#define IDC_RESETCAMERA                 1030
#define IDC_EDIT12                      1031
#define IDC_NUMSPACES                   1031
#define IDC_EDIT13                      1032
#define IDC_TABS                        1032
#define IDC_EDIT14                      1033
#define IDC_SPACES                      1033
#define IDC_EDIT15                      1034
#define IDC_VERSION                     1034
#define IDC_EDIT16                      1035
#define IDC_RENDERCONTINUOUSLY          1035
#define IDC_EDIT17                      1036
#define IDC_RENDERONREQUEST             1036
#define IDC_EDIT18                      1037
#define IDC_RENDER                      1037
#define IDC_EDIT19                      1038
#define IDC_EDIT20                      1039
#define IDC_EDIT21                      1040
#define IDC_EDIT22                      1041
#define IDC_EDIT23                      1042
#define IDC_HELP_EDITBOX                1043
#define ID_VIEW_RENDER                  32771
#define ID_VIEW_CHANGEDEVICE            32772
#define ID_SELECTLINE                   32773
#define ID_VIEW_CHOOSEFONT              32774
#define ID_VIEW_TABS                    32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
