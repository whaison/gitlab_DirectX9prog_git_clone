// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__712C53C9_D63B_11D1_A8B5_00C04FC2DC22__INCLUDED_)
#define AFX_STDAFX_H__712C53C9_D63B_11D1_A8B5_00C04FC2DC22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <winver.h>
#include <basetsd.h>
#include <d3d9.h>
#include <d3dx9.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.



#endif // !defined(AFX_STDAFX_H__712C53C9_D63B_11D1_A8B5_00C04FC2DC22__INCLUDED_)
