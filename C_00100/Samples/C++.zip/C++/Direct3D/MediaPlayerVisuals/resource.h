//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MediaPlayerVisuals.rc
//
#define IDS_PROJNAME                    100
#define IDS_EFFECTNAME                  101
#define IDS_BARSPRESETNAME              102
#define IDS_SCOPEPRESETNAME             103
#define IDR_MEDIAPLAYERVISUALS          104
#define IDS_DESCRIPTION                 105
#define IDD_PROPERTYDIALOG              106
#define IDC_BAR_WIDTH                   202
#define IDC_BAR_WIDTH_SPIN              203
#define IDC_BAR_SPACING                 204
#define IDC_BAR_SPACING_SPIN            205
#define IDR_DIRECTX4                    211
#define IDR_CIRCLE                      212
#define IDR_CUBEFACE                    213
#define IDD_BARS                        214
#define IDC_MESSAGEEDIT                 1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        215
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
