//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winmain.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAINFRAME                   101
#define IDD_FORMVIEW                    102
#define IDR_MAIN_ACCEL                  113
#define IDD_SELECTDEVICE                144
#define IDD_VIEWCODE                    170
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_DEVICECLIP_CHECK            1012
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDC_RENDERVIEW                  1050
#define IDC_VIEWCODEEDITBOX             1054
#define IDC_VIEWFULLSCREEN              1059
#define IDC_TEX0_NAME                   1100
#define IDC_SELECTTEX0                  1101
#define IDC_TEX1_NAME                   1108
#define IDC_SELECTTEX1                  1109
#define IDC_TEX2_NAME                   1116
#define IDC_SELECTTEX2                  1117
#define IDC_BLEND_FACTOR                1118
#define IDC_PRESET_EFFECTS              1119
#define IDC_DIFFUSE_COLOR               1120
#define IDC_TEX0_COLOROP                1201
#define IDC_TEX0_COLORARG1              1202
#define IDC_TEX0_COLORARG2              1203
#define IDC_TEX0_COLORARG0              1204
#define IDC_TEX0_ALPHAOP                1205
#define IDC_TEX0_ALPHAARG1              1206
#define IDC_TEX0_ALPHAARG2              1207
#define IDC_TEX0_ALPHAARG0              1208
#define IDC_TEX0_RESULT                 1209
#define IDC_TEX1_COLOROP                1301
#define IDC_TEX1_COLORARG1              1302
#define IDC_TEX1_COLORARG2              1303
#define IDC_TEX1_COLORARG0              1304
#define IDC_TEX1_ALPHAOP                1305
#define IDC_TEX1_ALPHAARG1              1306
#define IDC_TEX1_ALPHAARG2              1307
#define IDC_TEX1_ALPHAARG0              1308
#define IDC_TEX1_RESULT                 1309
#define IDC_TEX2_COLOROP                1401
#define IDC_TEX2_COLORARG1              1402
#define IDC_TEX2_COLORARG2              1403
#define IDC_TEX2_COLORARG0              1404
#define IDC_TEX2_ALPHAOP                1405
#define IDC_TEX2_ALPHAARG1              1406
#define IDC_TEX2_ALPHAARG2              1407
#define IDC_TEX2_ALPHAARG0              1408
#define IDC_TEX2_RESULT                 1409
#define IDM_EXIT                        40001
#define IDM_CHANGEDEVICE                40010
#define IDM_ALTENTER                    40010
#define IDM_TOGGLEFULLSCREEN            40011
#define IDC_VIEWCODE                    40011
#define IDM_PAUSE                       40018
#define IDM_SINGLESTEP                  40019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         1120
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
