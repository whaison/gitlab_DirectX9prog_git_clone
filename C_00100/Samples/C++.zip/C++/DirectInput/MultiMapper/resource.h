//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultiMapper.rc
//
#define IDC_RESET_OWNERSHIP             3
#define IDC_RESET_MAPPINGS              4
#define IDI_MAIN_ICON                   101
#define IDD_MAIN                        101
#define IDI_MAIN                        101
#define IDC_UD_AXIS_STATE_P1            1031
#define IDC_LR_AXIS_STATE_P1            1032
#define IDC_BUTTON_STATE_P1             1034
#define IDC_NUM_PLAYERS_COMBO           1035
#define IDC_PLAYER4_GROUP               1036
#define IDC_PLAYER3_GROUP               1037
#define IDC_PLAYER1_GROUP               1038
#define IDC_PLAYER2_GROUP               1039
#define IDC_UD_AXIS_STATE_P2            1040
#define IDC_LR_AXIS_STATE_P2            1041
#define IDC_BUTTON_STATE_P2             1042
#define IDC_UD_AXIS_STATE_P3            1043
#define IDC_LR_AXIS_STATE_P3            1044
#define IDC_BUTTON_STATE_P3             1045
#define IDC_UD_AXIS_STATE_P4            1046
#define IDC_LR_AXIS_STATE_P4            1047
#define IDC_BUTTON_STATE_P4             1048
#define IDC_WORLD_STATE                 1049
#define IDC_TEXT1_P2                    1050
#define IDC_TEXT2_P2                    1051
#define IDC_TEXT3_P2                    1052
#define IDC_TEXT1_P3                    1053
#define IDC_TEXT1_P4                    1054
#define IDC_TEXT2_P3                    1055
#define IDC_TEXT2_P4                    1056
#define IDC_TEXT3_P3                    1057
#define IDC_TEXT3_P4                    1058
#define IDC_DEVICE_ASSIGNED_P1          1069
#define IDC_DEVICE_ASSIGNED_P2          1070
#define IDC_DEVICE_ASSIGNED_P3          1071
#define IDC_DEVICE_ASSIGNED_P4          1072
#define IDM_CONFIGINPUT                 40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1070
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
