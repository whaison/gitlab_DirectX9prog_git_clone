//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by drumpad.rc
//
#define IDD_DLG_MAIN                    101
#define IDD_DLG_DIDCV                   102
#define IDI_ICON                        103
#define IDC_BUTTON_BASS                 1001
#define IDC_BUTTON_SNARE                1002
#define IDC_BUTTON_HIHAT_UP             1003
#define IDC_BUTTON_HIHAT_DOWN           1004
#define IDC_BUTTON_CRASH                1005
#define IDC_BUTTON_USER1                1006
#define IDC_BUTTON_USER2                1007
#define IDC_BUTTON_USER3                1008
#define IDC_TEXT_FILENAME1              1010
#define IDC_TEXT_FILENAME2              1011
#define IDC_TEXT_FILENAME3              1012
#define IDC_TEXT_FILENAME4              1013
#define IDC_TEXT_FILENAME5              1014
#define IDC_TEXT_FILENAME6              1015
#define IDC_TEXT_FILENAME7              1016
#define IDC_TEXT_FILENAME8              1017
#define IDC_BUTTON_DEVICE               1020
#define IDC_BUTTON_JOY_VIEW_PREV        1021
#define IDC_BUTTON_JOY_VIEW_NEXT        1023
#define IDC_EDIT_TEXT                   1024
#define IDC_CHECK_COMPACT               1025
#define IDC_CHECK_JOY_SHOW_ALL          1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
