//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ActionBasic.rc
//
#define IDD_APPDIALOG                   101
#define IDI_ICON1                       102
#define IDCHART                         1003
#define IDC_CONFIG                      1004
#define IDC_CHART                       -1
#define IDC_BOX                         -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
