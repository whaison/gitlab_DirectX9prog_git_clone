//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mouse.rc
//
#define IDI_MAIN                        102
#define IDD_MOUSE                       102
#define IDR_MENU                        103
#define IDR_ACCELERATOR1                105
#define IDC_DATA                        1000
#define IDC_CREATEDEVICE                1010
#define IDC_BEHAVIOR                    1012
#define IDC_DATA_STATIC                 1013
#define IDC_HELP_TEXT                   1015
#define IDC_EXCLUSIVE                   1110
#define IDC_NONEXCLUSIVE                1111
#define IDC_FOREGROUND                  1120
#define IDC_BACKGROUND                  1121
#define IDC_IMMEDIATE                   1130
#define IDC_BUFFERED                    1131
#define IDM_CREATEDEVICE                40003
#define IDM_RELEASEDEVICE               40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
