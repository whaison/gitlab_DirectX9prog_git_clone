//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by keyboard.rc
//
#define IDI_MAIN                        102
#define IDD_KEYBOARD                    102
#define IDR_ACCELERATOR1                103
#define IDC_DATA                        1000
#define IDC_CREATEDEVICE                1010
#define IDC_BEHAVIOR                    1012
#define IDC_DATA_STATIC                 1013
#define IDC_WINDOWSKEY                  1014
#define IDC_EXCLUSIVE                   1110
#define IDC_NONEXCLUSIVE                1111
#define IDC_FOREGROUND                  1120
#define IDC_BACKGROUND                  1121
#define IDC_IMMEDIATE                   1130
#define IDC_BUFFERED                    1131

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
