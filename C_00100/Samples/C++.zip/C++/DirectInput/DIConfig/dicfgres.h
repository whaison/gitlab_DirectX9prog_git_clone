//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dconfig.rc
//

#define IDS_MSGBOXTITLE_WRITEINISUCCEEDED 1
#define IDS_MSGBOXTITLE_WRITEINIFAILED  2
#define IDS_WROTEINITO                  3
#define IDS_DICREATEFAILED              4
#define IDS_CREATEDEVICEFAILED          5
#define IDS_GETPROPMAPFILEFAILED        6
#define IDS_WCTOMBFAILED                7
#define IDS_NOMAPFILEPATH								8
#define IDS_ERRORUNKNOWN                9
#define IDS_REMOVEALLCALLOUTS           10
#define IDS_CONFIRMREMOVEALLCALLOUTS    11
#define IDS_REMOVEVIEW                  12
#define IDS_CONFIRMREMOVEVIEW           13
#define IDS_REMOVEALLVIEWS              14
#define IDS_CONFIRMREMOVEALLVIEWS       15
#define IDS_TITLE_NONEWCONTROL          16
#define IDS_ERROR_OFFSETUNAVAIL         17
#define IDS_GETPROPVIDPIDFAILED         18
#define IDS_ERROR_INIREAD               19
#define IDS_ERROR_CANTLOADDIMAP         20
#define IDS_ERROR_OUTOFMEMORY           21
#define IDS_BUTTON_LAYOUT               22
#define IDS_ERROR_WRITEVENDORFILE_FAILED 23
#define IDS_WRITEVENDORFILE_ACCESSDENIED 24

#define IDS_DCONFIG_PRODUCTNAME         25
#define IDS_BUTTON_OK                   26
#define IDS_TITLE_NOLOADVIEWIMAGE       27
#define IDS_NULLPATH                    28
#define IDS_COULDNOTCREATEIMAGEFROMFILE 29
#define IDS_BUTTON_CANCEL               30
#define IDS_BUTTON_RESET                31
#define IDS_INFOMSG_VIEW_TAB            32
#define IDS_INFOMSG_VIEW_TABSCROLL      33
#define IDS_INFOMSG_VIEW_DEVICE         34
#define IDS_INFOMSG_VIEW_SORTDISABLED   35
#define IDS_INFOMSG_VIEW_SORTENABLED    36
#define IDS_INFOMSG_VIEW_VIEWSEL        37
#define IDS_INFOMSG_VIEW_OK             38
#define IDS_INFOMSG_VIEW_USERNAME       39
#define IDS_INFOMSG_VIEW_GAMEMODE       40
#define IDS_INFOMSG_EDIT_TAB            41
#define IDS_INFOMSG_EDIT_TABSCROLL      42
#define IDS_INFOMSG_EDIT_DEVICE         43
#define IDS_INFOMSG_EDIT_SORTDISABLED   44
#define IDS_INFOMSG_EDIT_SORTENABLED    45
#define IDS_INFOMSG_EDIT_VIEWSEL        46
#define IDS_INFOMSG_EDIT_RESET          47
#define IDS_INFOMSG_EDIT_OK             48
#define IDS_INFOMSG_EDIT_CANCEL         49
#define IDS_INFOMSG_EDIT_ACTLISTDISABLED 50
#define IDS_INFOMSG_EDIT_ACTLISTENABLED 51
#define IDS_INFOMSG_EDIT_USERNAME       52
#define IDS_INFOMSG_EDIT_GAMEMODE       53
#define IDS_INFOMSG_DEF_EDIT            54
#define IDS_INFOMSG_DEF_VIEW            55
#define IDS_INFOMSG_EDIT_CTRLSELECTED   56
#define IDS_INFOMSG_EDIT_EDITMODEENABLED 57
#define IDS_INFOMSG_EDIT_KEYBOARD       58
#define IDS_INFOMSG_EDIT_MOUSE          59
#define IDS_INFOMSG_APPFIXEDSELECT      60
#define IDS_INFO_TITLE                  61
#define IDS_PLAYER_TITLE                62
#define IDS_GENRE_TITLE                 63
#define IDS_AVAILABLEACTIONS_TITLE      64
#define IDS_SORTASSIGNED                65
#define IDS_AXISACTIONS                 66
#define IDS_BUTTONACTIONS               67
#define IDS_POVACTIONS                  68
#define IDS_LISTHEADER_CTRL             69
#define IDS_LISTHEADER_ACTION           70
#define IDS_RESETMSG                    71
#define IDD_DIACPAGE                    102
#define IDD_SELCONTROLDLG               103
#define IDD_DCONFIG_DIALOG              104
#define IDB_IB                          105
#define IDB_IB2                         106
#define IDB_HATGLYPH                    107
#define IDB_BUTTONGLYPH                 108
#define IDB_CHECKGLYPH                  109
#define IDB_AXESGLYPH                   110
#define IDB_CHECKGLYPHDARK              111
#define IDC_TAB                         1001
#define IDC_DEFAULT                     1002
#define IDC_LIST                        1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
