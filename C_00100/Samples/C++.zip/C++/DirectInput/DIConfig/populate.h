//-----------------------------------------------------------------------------
// File: populate.h
//
// Desc: Implements PopulateAppropriately.
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//-----------------------------------------------------------------------------

#ifndef __POPULATE_H__
#define __POPULATE_H__


HRESULT PopulateAppropriately(CDeviceUI &ui);


#endif //__POPULATE_H__
