//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomFormat.rc
//
#define IDD_MOUSE_IMM                   101
#define IDI_MAIN                        102
#define IDC_X_AXIS_TEXT                 1000
#define IDC_Y_AXIS_TEXT                 1001
#define IDC_BUTTONS_TEXT                1002
#define IDC_X_AXIS                      1003
#define IDC_Y_AXIS                      1004
#define IDC_BUTTONS                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
