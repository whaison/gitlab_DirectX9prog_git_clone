//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DeviceView.rc
//
#define IDD_DIALOG1                     101
#define IDI_MAIN                        103
#define IDC_DEVICES                     1005
#define IDC_IMAGE                       1006
#define IDC_HIDE                        1007
#define IDC_MAXVIEW                     1013
#define IDC_CURVIEW                     1014
#define IDC_SPIN                        1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
