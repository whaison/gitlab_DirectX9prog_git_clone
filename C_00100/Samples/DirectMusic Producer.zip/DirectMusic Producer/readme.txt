DirectMusic(r) Producer in DirectX(r) version 9

DirectMusic is a DirectX technology. Designed to provide an extensible music
solution for DirectX platforms, DirectMusic provides a large palette of tools
for creating high-quality interactive and non-repetitive music and audio content.
By providing a framework for musical interactivity, DirectMusic lets you build
musical intelligence into multimedia titles for Windows. 

DirectMusic introduces technologies and file formats that have previously not
been available.  To allow composers to integrate the resources of DirectMusic 
with the consistent sound performance of Downloadable Sounds (DLS), an authoring 
tool is included in this SDK.  This authoring tool is DirectMusic Producer. 

Within DirectMusic Producer, individual file objects, such as waves, MIDI files, 
styles, chordmaps, segments, and DLS files, are supported by integrated editor 
modules that know how to communicate with each other and work synchronously, 
providing real-time interactive editing on top of the DirectMusic engine.

DirectMusic Producer consists of the following elements:

a. Framework: the environment that hosts all authoring components.

b. Conductor component: acts as the liaison between authoring components
   and the DirectMusic engine.

c. Style Designer component: provides for creation of interactive music files.

d. Chordmap Designer component: variable chords and scales.

e. Band Editor component: used for assigning instrument settings (patch changes)
   including DLS.

f. Segment Designer component: allows for open-ended creation of different track
   types to be integrated into musical compositions.  MIDI, wave and style 
   files can be used together or independently.

h. DLS Designer component: for creation of Downloadable Sounds soundsets for 
   both DLS1 and DLS2 format.

e. Script Designer: allows the composer or sound designer to use a basic 
   scripting language to control the behavior of content playback.  Detailed 
   information can be found in the DirectMusic Producer Help file under the 
   topic Script Designer.

f. Audiopath Designer: provides the user with the ability to create mix groups,
   route mix groups to specific ports, and to set up real-time software effects via 
   DirectX Media Objects (DMO's).  

The DirectMusic Producer setup will automatically uninstall any existing versions
of DirectMusic Producer found on your machine. It is recommended that you close 
DirectMusic Producer before attempting to install. 

DirectMusic Producer requires the DirectX 9 version of DirectMusic, as its 
functionality is built entirely on top of DirectMusic. The Producer installation 
process will prompt you to install the correct runtime software, if it is not 
already present.  

DirectMusic Producer also requires Internet Explorer 6.0 or later. 

The Help documentation includes a basic tutorial as well as a brand new advanced
tutorial to introduce some DirectMusic concepts.  An additional project of sample 
content can be found on the SDK CD at "\sdk\Essentials\DMusProd\DemoContent\
DMPDemoContent.exe". Note that this sample content has not changed since DirectX 8.0,
so if you have previously installed it there is no need to reinstall. The project 
will install to "My Documents\DMUSProducer\Demo8\" on your hard drive.

For more detailed and up-to-date information on DirectMusic Producer, please
read dmusprod.txt after installing DirectMusic Producer.