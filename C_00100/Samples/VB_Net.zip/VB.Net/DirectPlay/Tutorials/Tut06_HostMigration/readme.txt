//-----------------------------------------------------------------------------
// Name: HostMigration DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The HostMigration tutorial is the 6th tutorial for DirectPlay.  It builds upon the last 
   tutorial and adds host migration
  
Path
====
   Source: DXSDK\Samples\VB.NET\DirectPlay\Tutorials\Tut06_HostMigration
