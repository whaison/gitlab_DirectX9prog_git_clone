//-----------------------------------------------------------------------------
// Name: Send DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The Send tutorial is the 5th tutorial for DirectPlay.  It builds upon the last 
   tutorial and adds a send
  
Path
====
   Source: DXSDK\Samples\VB.NET\DirectPlay\Tutorials\Tut05_Send
