//-----------------------------------------------------------------------------
// Name: ClientServer DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The ClientServer tutorial is the 5th tutorial for DirectPlay.  It builds upon the last 
   tutorial and adds a ClientServer
  
Path
====
   Source: DXSDK\Samples\VB.NET\DirectPlay\Tutorials\Tut05_ClientServer
