//-----------------------------------------------------------------------------
// Name: Voice DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The Voice tutorial is the 8th tutorial for DirectPlay.  It builds upon the last 
   tutorial and adds voice support
  
Path
====
   Source: DXSDK\Samples\VB\DirectPlay\Tutorials\Tut08_Voice
