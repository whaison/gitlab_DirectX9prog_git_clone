//-----------------------------------------------------------------------------
// Name: LobbyLaunch DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The LobbyLaunch tutorial is the 7th tutorial for DirectPlay.  It builds upon 
   the last tutorial and adds lobby launching
  
Path
====
   Source: DXSDK\Samples\VB.NET\DirectPlay\Tutorials\Tut07_LobbyLaunch
