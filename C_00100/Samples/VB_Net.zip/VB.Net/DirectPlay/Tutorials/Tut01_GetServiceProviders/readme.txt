//-----------------------------------------------------------------------------
// Name: GetServiceProviders DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The GetServiceProviders tutorial is the first tutorial for inits DirectPlay and enumerates 
   the available DirectPlay Service Providers.

   
Path
====
   Source: DXSDK\Samples\VB.NET\DirectPlay\Tutorials\Tut01_GetServiceProviders
