//-----------------------------------------------------------------------------
// 
// Sample Name: Video Texture Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  This sample demonstrates placing video on a 3D surface.

Path
====
  Source:     DXSDK\Samples\VB.NET\AudioVideo\Texture
  Executable: DXSDK\Samples\VB.NET\AudioVideo\Bin

User's Guide
============
  Open a file and play it.

