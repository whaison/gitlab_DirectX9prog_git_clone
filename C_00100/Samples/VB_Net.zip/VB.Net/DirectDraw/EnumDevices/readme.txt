//-----------------------------------------------------------------------------
// 
// Sample Name: EnumDevices Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  This sample shows how to enumerate the current DirectDraw devices.

Path
====
   Source:     DXSDK\Samples\VB.NET\DirectDraw\EnumDevices
   Executable: DXSDK\Samples\VB.NET\DirectDraw\Bin

User's Guide
============
  The user interface is a simple dialog box. 

  

