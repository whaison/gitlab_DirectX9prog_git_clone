//-----------------------------------------------------------------------------
// 
// Sample Name: WindowedMode Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  WindowedMode demonstrates the tasks required to initialize and run 
  a windowed DirectDraw application.

Path
====
   Source:     DXSDK\Samples\VB.NET\DirectDraw\Windowed
   Executable: DXSDK\Samples\VB.NET\DirectDraw\Bin

User's Guide
============
  WindowedMode requires no user input. Press the ESC key to quit the program.

