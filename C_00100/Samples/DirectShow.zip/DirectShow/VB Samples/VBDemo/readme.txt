DirectShow Sample -- VBDemo
---------------------------

This is a simple media player application for Microsoft Visual Basic.

Open a media file from the File menu, and it will begin playing automatically.
You can control playback speed with the radio buttons at the bottom of the form.
While the file plays, VBDemo displays information about the media file's 
duration and current position.  You may also adjust volume and balance by
adjusting the slider controls beneath the video window.

Note:  Adjusting playback speed of .ASF files is not supported.
