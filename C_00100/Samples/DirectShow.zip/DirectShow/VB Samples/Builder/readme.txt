DirectShow Sample -- Builder
----------------------------

Graph building application for Microsoft Visual Basic.

This sample application demonstrates how to build custom filter graphs 
using Microsoft Visual Basic.


