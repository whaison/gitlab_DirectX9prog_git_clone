DirectShow Sample -- XTLTestVB
------------------------------

Microsoft Visual Basic application that previews video editing project files.
This is a Visual Basic version of the XTLTest C++ sample, but with 
limited functionality.  It demonstrates how to quickly read an XTL file, 
create a render engine, and start playing the resultant DirectShow graph 
based on the XTL file.

To use this application, drag a Microsoft DirectShow Editing Services XTL file 
onto the application window.  You can use this sample as a quick and easy 
player for your XTL files.

