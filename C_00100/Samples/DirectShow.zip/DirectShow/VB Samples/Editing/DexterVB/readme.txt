DirectShow Sample -- DexterVB
-----------------------------

Video editing application for Microsoft Visual Basic.

This sample application is a graphical tool for creating Microsoft DirectShow 
Editing Services timelines. It demonstrates the following tasks:

- Loading and saving XTL project files 
- Adding, editing, and deleting timeline objects 
- Previewing a timeline 

For more information about this sample, see "DirectShow Samples" in the
DirectX 8 SDK documentation.
