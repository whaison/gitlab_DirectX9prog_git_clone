//-----------------------------------------------------------------------------
// Name: DxDiagOutput Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The DxDiagOutput sample shows how to use the DxDiag managed DirectX interfaces
   by enumerating every child container and enumerating the properties on each 
   child container.


Path
====
   Source:     DXSDK\Samples\C#\Misc\DxDiagOutput
   Executable: DXSDK\Samples\C#\Misc\Bin


User's Guide
============
   Simply run the sample and it will enumerate and display all information 
   to the console window.
          