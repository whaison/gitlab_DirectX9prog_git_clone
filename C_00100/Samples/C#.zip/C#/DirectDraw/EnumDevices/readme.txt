//-----------------------------------------------------------------------------
// 
// Sample Name: EnumDevices Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  This sample shows how to enumerate the current DirectDraw devices.

Path
====
   Source:     DXSDK\Samples\C#\DirectDraw\EnumDevices
   Executable: DXSDK\Samples\C#\DirectDraw\Bin

User's Guide
============
  The user interface is a simple dialog box. 

  

