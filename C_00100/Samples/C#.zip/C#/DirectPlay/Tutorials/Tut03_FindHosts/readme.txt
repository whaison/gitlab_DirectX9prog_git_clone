//-----------------------------------------------------------------------------
// Name: FindHosts DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The FindHosts tutorial is the 3nd tutorial for DirectPlay.  It builds upon the last 
   tutorial and adds the enumerating the hosts at a given target address
  
Path
====
   Source: DXSDK\Samples\C#\DirectPlay\Tutorials\Tut03_FindHosts
