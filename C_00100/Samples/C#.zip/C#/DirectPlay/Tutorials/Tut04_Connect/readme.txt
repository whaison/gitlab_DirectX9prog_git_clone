//-----------------------------------------------------------------------------
// Name: Connect DirectPlay Tutorial
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The Connect tutorial is the 4th tutorial for DirectPlay.  It builds upon 
   the last tutorial and adds the enumerating the hosts at a given target address
  
Path
====
   Source: DXSDK\Samples\C#\DirectPlay\Tutorials\Tut04_Connect
