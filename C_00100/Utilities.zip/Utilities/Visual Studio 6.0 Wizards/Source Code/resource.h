//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DxAppWiz.rc
//
#define IDD_CUSTOM1                     129
#define IDD_CUSTOM2                     130
#define IDD_CUSTOM3                     131
#define IDD_CUSTOM4                     132
#define IDD_CUSTOM5                     133
#define IDD_CUSTOM6                     134
#define IDD_CUSTOM7                     135
#define IDD_CUSTOM8                     136
#define IDR_TEMPLATE1                   142
#define IDB_BACKGROUND                  144
#define IDB_WIN_TEAPOT                  146
#define IDB_WIN_TRIANGLE                147
#define IDB_WIN_BLANK                   148
#define IDB_DLG_TEAPOT                  149
#define IDB_DLG_TRIANGLE                150
#define IDB_DLG_BLANK                   151
#define IDB_DLG_GDI                     152
#define IDB_WIN_GDI                     153
#define IDC_TEXTURE                     1000
#define IDC_XFILE                       1002
#define IDC_MENUBAR                     1003
#define IDC_DEVICE_SELECTION            1005
#define IDC_FPS                         1006
#define IDC_FULLSCREEN                  1007
#define IDC_WINDOWED                    1008
#define IDC_SHOW_BLANK                  1011
#define IDC_SHOW_TRIANGLE               1012
#define IDC_SHOW_TEAPOT                 1013
#define IDC_DINPUT                      1015
#define IDC_DMUSIC                      1016
#define IDC_DPLAY                       1017
#define IDC_DSOUND                      1018
#define IDC_D3DFONT                     1019
#define IDC_WINDOW                      1020
#define IDC_MFCDIALOG                   1021
#define IDC_DPLAYVOICE                  1025
#define IDC_DIRECT3D                    1026
#define IDC_ADDMENUS                    1027
#define IDC_BACKGROUND                  1028
#define IDC_PREVIEW                     1029
#define IDC_REGINCLUDE                  1030
#define IDC_ACTIONMAPPER                1031
#define IDC_KEYBOARD                    1032
#define IDI_ICON1                       1340

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
