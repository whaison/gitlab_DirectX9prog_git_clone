//-------------------------------------------------------------
// File: main.cpp
//
// Desc: �c��
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_WIDTH	512
#define MAP_HEIGHT	512


// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pMesh						= new CD3DMesh();
	m_pMeshBg					= new CD3DMesh();

	m_fLast						= 0;
	
	m_pZ						= NULL;
	m_pTex						= NULL;
	m_pSurf						= NULL;

	m_fWorldRotX                = -0.54f;
    m_fWorldRotY                = 1.41f;
	m_fViewZoom				    = 4.0f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �Ԃ̓ǂݍ���
	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, _T("ufo.x"))))
        return DXTRACE_ERR( "LoadCar", hr );
	// �n�ʂ̓ǂݍ���
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load BG", hr );
        
	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
	m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);

	// ���b�V��
	m_pMesh  ->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );

    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );


    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	TSS( 0, D3DTSS_ALPHAARG1,	D3DTA_TEXTURE);
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	// �����_�����O�^�[�Q�b�g�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(
					MAP_WIDTH, MAP_HEIGHT, D3DFMT_D16,
					D3DMULTISAMPLE_NONE, 0, TRUE, &m_pZ, NULL)))
		return E_FAIL;

	m_pd3dDevice->SetDepthStencilSurface(NULL);
	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) ){
		if (FAILED(m_pd3dDevice->CreateTexture(
					MAP_WIDTH, MAP_HEIGHT, 1,
					D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,
					D3DPOOL_DEFAULT, &m_pTex, NULL)))
			return E_FAIL;
		if (FAILED(m_pTex->GetSurfaceLevel(0, &m_pSurf)))
			return E_FAIL;
		// �h��Ԃ��ď���������
		m_pd3dDevice->SetRenderTarget(0, m_pSurf);
		m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET
						, 0xffffffff, 1.0f, 0L);
		m_pd3dDevice->EndScene();
	}
	//-----------------------------------------------------
	// �����_�����O�^�[�Q�b�g�����ɖ߂�
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	pOldBackBuffer->Release();
	pOldZBuffer->Release();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	// ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else
    if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else
    if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );

    pUserInput->bDispersionUp   = ( m_bActive && (GetAsyncKeyState( VK_PRIOR) & 0x8000) == 0x8000 );
    pUserInput->bDispersionDown = ( m_bActive && (GetAsyncKeyState( VK_NEXT ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mView, mProj;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	DWORD i;

	// �r���[�|�[�g
	D3DVIEWPORT9 viewport = {0,0      // ����̍��W
					, MAP_WIDTH  // ��
					, MAP_HEIGHT // ����
					, 0.0f,1.0f};     // �O�ʁA���

	//-------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̕ۑ�
	//-------------------------------------------------
	m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
	m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
	m_pd3dDevice->GetViewport(&oldViewport);

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		const DWORD RENDERING_COUNT = 10;// �`���

		for(i=0;i<RENDERING_COUNT;i++){
			FLOAT time = m_fLast
				+ (m_fTime-m_fLast)*((FLOAT)i+1)/RENDERING_COUNT;

			// �����_�����O�^�[�Q�b�g�̕ύX
			m_pd3dDevice->SetRenderTarget(0, m_pSurf);
			m_pd3dDevice->SetDepthStencilSurface(m_pZ);
			m_pd3dDevice->SetViewport(&viewport);
			
			DWORD alpha = 255/(i+1);
			m_pd3dDevice->Clear(0L, NULL
							, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
							, D3DCOLOR_RGBA(0,0,0,alpha), 1.0f, 0L);
			RS(D3DRS_COLORWRITEENABLE, 0x7);
			//-------------------------------------------------
			// ���ʂ̃V�[���̕`��
			//-------------------------------------------------
			m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m_mWorld);
			m_pd3dDevice->SetTransform( D3DTS_VIEW,  &m_mView );
			m_pd3dDevice->SetTransform( D3DTS_PROJECTION,  &m_mProj );

			RS( D3DRS_ZENABLE, TRUE );
			RS( D3DRS_LIGHTING, TRUE );
			TSS( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
			TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
			m_pMeshBg->Render( m_pd3dDevice );
			
			// ��s���f���̕`��
			TSS( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
			TSS( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE );
			RS( D3DRS_LIGHTING, TRUE );
			RS( D3DRS_AMBIENT, 0 );
			m_pd3dDevice->LightEnable( 0, TRUE );
			D3DXMatrixTranslation( &m, 1.0f, 0.0f ,0.0f );
			D3DXMatrixRotationY( &mR,  time );
			D3DXMatrixTranslation( &mT, 1.0f, 1.0f ,0.0f );
			m = m * mR * mT * m_mWorld;
			m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m);
			m_pMesh  ->Render( m_pd3dDevice );

			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�����ɖ߂�
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
			m_pd3dDevice->SetDepthStencilSurface(NULL);
			m_pd3dDevice->SetViewport(&oldViewport);
			
			RS( D3DRS_ZENABLE, FALSE );
			RS( D3DRS_LIGHTING, FALSE );
			RS( D3DRS_COLORWRITEENABLE, 0xf);
			TSS(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
			TSS(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);

			RS( D3DRS_ALPHABLENDENABLE, TRUE);
			RS( D3DRS_SRCBLEND,   D3DBLEND_SRCALPHA);
			RS( D3DRS_DESTBLEND,  D3DBLEND_INVSRCALPHA);

			//-----------------------------------------------------
			// ���̂܂ܒ���
			//-----------------------------------------------------
			FLOAT w = (FLOAT)oldViewport.Width;
			FLOAT h = (FLOAT)oldViewport.Width;
			TVERTEX Vertex1[4] = {
				//x  y   z    rhw  tu tv
				{ 0, 0, 0.1f, 1.0f, 0, 0,},
				{ w, 0, 0.1f, 1.0f, 1, 0,},
				{ w, h, 0.1f, 1.0f, 1, 1,},
				{ 0, h, 0.1f, 1.0f, 0, 1,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			m_pd3dDevice->SetTexture(0, m_pTex);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex1, sizeof( TVERTEX ) );

			RS(D3DRS_ALPHABLENDENABLE, FALSE);
			
		}
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);

		// ���݂̎��Ԃ̕ۑ�
		m_fLast = m_fTime;

        // �w���v�̕\��
        RenderText();

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 128.0f;
		for(DWORD i=0; i<1; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pTex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

	pOldBackBuffer->Release();
	pOldZBuffer->Release();
	
	Sleep(100);

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// �V���h�E�}�b�v
	SAFE_RELEASE(m_pSurf);
	SAFE_RELEASE(m_pTex);
	SAFE_RELEASE(m_pZ);

	m_pMesh  ->InvalidateDeviceObjects(); // ���b�V��
	m_pMeshBg->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// ���b�V��
	m_pMesh  ->Destroy();
	m_pMeshBg->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼�O�ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pMeshBg ); // ���b�V��
	SAFE_DELETE( m_pMesh );

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




